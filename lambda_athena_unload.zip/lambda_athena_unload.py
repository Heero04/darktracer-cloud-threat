import boto3
import os
import time
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Get environment and project name from environment variables
PROJECT_NAME = os.environ.get('PROJECT_NAME', 'darktracer')
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'dev')

# Make database and table names dynamic
ATHENA_DATABASE = f"{PROJECT_NAME}_clean_logs_{ENVIRONMENT}"
ATHENA_TABLE = os.environ.get('ATHENA_TABLE', 'honeypot_logs')
ATHENA_OUTPUT = f"s3://{PROJECT_NAME}-training-bucket-{ENVIRONMENT}/athena-results/"
UNLOAD_TARGET = f"s3://{PROJECT_NAME}-training-bucket-{ENVIRONMENT}/input/"

athena = boto3.client('athena')

def run_query(query):
    try:
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': ATHENA_DATABASE},
            ResultConfiguration={'OutputLocation': ATHENA_OUTPUT}
        )
        return response['QueryExecutionId']
    except Exception as e:
        logger.error(f"Error executing query: {str(e)}")
        raise

def wait_for_query(execution_id, timeout=300):  # 5 minutes timeout
    start_time = time.time()
    while True:
        if time.time() - start_time > timeout:
            raise Exception("Query timeout exceeded")
        
        status = athena.get_query_execution(QueryExecutionId=execution_id)
        state = status['QueryExecution']['Status']['State']
        
        if state == 'FAILED':
            reason = status['QueryExecution']['Status'].get('StateChangeReason', 'No reason provided')
            raise Exception(f"Query failed: {reason}")
            
        if state in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
            return state
            
        time.sleep(1)

def get_query_results(execution_id):
    try:
        result = athena.get_query_results(QueryExecutionId=execution_id)
        return result['ResultSet']['Rows']
    except Exception as e:
        logger.error(f"Error getting query results: {str(e)}")
        raise

def cleanup_query_results(execution_id):
    try:
        athena.delete_named_query(execution_id)
    except Exception as e:
        logger.error(f"Error cleaning up query: {str(e)}")

def lambda_handler(event, context):
    try:
        # Get count of records
        count_query = f"SELECT COUNT(*) FROM {ATHENA_TABLE}"
        logger.info(f"Executing count query: {count_query}")
        
        exec_id = run_query(count_query)
        if wait_for_query(exec_id) != 'SUCCEEDED':
            raise Exception("Count query failed.")
        
        rows = get_query_results(exec_id)
        count = int(rows[1]['Data'][0]['VarCharValue']) if len(rows) > 1 else 0
        
        logger.info(f"Found {count} rows to process")
        
        if count > 0:
            # Perform UNLOAD operation
            unload_query = f"""
            UNLOAD (SELECT 
            timestamp,
            message 
            FROM {ATHENA_TABLE})
            TO '{UNLOAD_TARGET}'
            WITH (format = 'CSV')
            """
            logger.info("Starting UNLOAD operation")
            unload_id = run_query(unload_query)
            
            if wait_for_query(unload_id) != 'SUCCEEDED':
                raise Exception("UNLOAD query failed.")
                
            logger.info("Successfully unloaded data")
            
            # Cleanup
            cleanup_query_results(exec_id)
            cleanup_query_results(unload_id)
        else:
            logger.info("No data to unload.")
            cleanup_query_results(exec_id)
        
        return {
            'statusCode': 200,
            'body': f'Successfully processed {count} rows',
            'unloadLocation': UNLOAD_TARGET
        }
        
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Error processing request: {str(e)}'
        }
