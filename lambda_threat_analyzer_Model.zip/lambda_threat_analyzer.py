import json
import boto3
import os
from datetime import datetime
import base64
import gzip
import ipaddress
import onnxruntime as rt
import numpy as np

# AWS clients
waf_client = boto3.client('wafv2')
sns_client = boto3.client('sns')
ec2_client = boto3.client('ec2')
s3_client = boto3.client('s3')

# Load ONNX model from S3 to /tmp (only done on cold start)
def load_model():
    bucket = os.environ['MODEL_BUCKET']
    key = os.environ['MODEL_KEY']
    local_path = '/tmp/model.onnx'
    s3_client.download_file(bucket, key, local_path)
    return rt.InferenceSession(local_path)

model = load_model()
input_name = model.get_inputs()[0].name

def handler(event, context):
    try:
        if 'awslogs' in event:
            compressed_payload = base64.b64decode(event['awslogs']['data'])
            uncompressed_payload = gzip.decompress(compressed_payload)
            log_data = json.loads(uncompressed_payload)
            
            for log_event in log_data['logEvents']:
                try:
                    honeypot_data = json.loads(log_event['message'])
                    src_host = honeypot_data.get('src_host')
                    dst_port = honeypot_data.get('dst_port')

                    # Skip internal IPs
                    if is_internal_ip(src_host):
                        continue

                    # --- Run prediction using ONNX model ---
                    features = extract_features(honeypot_data)
                    pred = model.run(None, {input_name: features})[0][0]

                    if pred == 1:
                        print(f"Threat detected from {src_host} on port {dst_port}")

                        waf_blocked = update_ip_set(waf_client, src_host, os.environ['IP_SET_ID'])

                        port_closed = False
                        if dst_port and os.environ.get('SECURITY_GROUP_ID'):
                            port_closed = close_port_in_security_group(os.environ['SECURITY_GROUP_ID'], dst_port)

                        message_data = {
                            'timestamp': datetime.utcnow().isoformat(),
                            'ip_address': src_host,
                            'port_attacked': dst_port,
                            'attack_details': honeypot_data,
                            'actions_taken': {
                                'waf_blocked': waf_blocked,
                                'port_closed': port_closed
                            }
                        }
                        publish_to_sns(sns_client, message_data)

                except json.JSONDecodeError:
                    continue

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Processed'})
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

# --- Util functions below remain the same ---

def extract_features(data):
    # Extract features in the order your model expects
    return np.array([[
        int(data.get('src_port', 0)),
        int(data.get('dst_port', 0)),
        int(data.get('logtype', 0)),
        0  # Add more if needed (placeholder)
    ]], dtype=np.float32)

def update_ip_set(waf_client, ip_address, ip_set_id, scope='REGIONAL'):
    try:
        response = waf_client.get_ip_set(
            Name=f"{os.environ.get('PROJECT_NAME', 'darktracer')}-blocked-ip-set-{os.environ.get('ENV', 'dev')}",
            Scope=scope,
            Id=ip_set_id
        )
        addresses = response['IPSet']['Addresses']
        new_ip = f"{ip_address}/32"
        if new_ip not in addresses:
            addresses.append(new_ip)
            waf_client.update_ip_set(
                Name=response['IPSet']['Name'],
                Scope=scope,
                Id=ip_set_id,
                Addresses=addresses,
                LockToken=response['LockToken']
            )
            print(f"Added {ip_address} to WAF blocklist")
            return True
        return False
    except Exception as e:
        print(f"WAF update error: {str(e)}")
        return False

def close_port_in_security_group(security_group_id, port):
    try:
        response = ec2_client.describe_security_groups(GroupIds=[security_group_id])
        permissions = response['SecurityGroups'][0]['IpPermissions']
        revoke_permissions = [perm for perm in permissions if (
            perm.get('FromPort') == int(port) and perm.get('ToPort') == int(port) and perm.get('IpProtocol') == 'tcp')]
        if not revoke_permissions:
            print(f"No rule for port {port}")
            return True
        ec2_client.revoke_security_group_ingress(
            GroupId=security_group_id,
            IpPermissions=revoke_permissions
        )
        print(f"Closed port {port}")
        return True
    except Exception as e:
        print(f"Security group error: {str(e)}")
        return False

def publish_to_sns(sns_client, message_data):
    try:
        sns_client.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject='Security Alert - Threat Detected',
            Message=json.dumps(message_data, indent=2)
        )
        print("SNS alert sent")
        return True
    except Exception as e:
        print(f"SNS error: {str(e)}")
        return False

def is_internal_ip(ip):
    ip_obj = ipaddress.ip_address(ip)
    return any([
        ip_obj in ipaddress.ip_network('10.0.0.0/8'),
        ip_obj in ipaddress.ip_network('172.16.0.0/12'),
        ip_obj in ipaddress.ip_network('192.168.0.0/16')
    ])

